from pathlib import Path
import json,subprocess,hashlib,time,datetime,os,sys
root=Path('/dev/shm/relay17-rf297-acceptance')
evd=Path('/dev/shm/relay17-rf297-acceptance-evidence')
manifest=json.loads((evd/'candidate-manifest.json').read_text())
def verify():
 errors=[]
 for f in manifest['files']:
  b=(root/f['path']).read_bytes()
  sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
  if sha!=f['sha']: errors.append(f['path'])
 if errors: raise RuntimeError('Source changed: '+repr(errors))
verify()
env=dict(os.environ,TMPDIR='/dev/shm/relay17-rf297-acceptance-tmp')
cmd=['node','node_modules/vitest/vitest.mjs','run','test/integration','test/unit','test/components','test/services','test/lighthouse-config.test.js','test/security','--config',str(evd/'vitest.config.mjs'),'--maxWorkers=2','--reporter=default','--reporter=json','--outputFile.json='+str(evd/'vitest-results.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
with (evd/'vitest-output.log').open('w') as out:
 p=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
verify()
receipt={'started_at_utc':start,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-t,'exit_code':p.returncode,'command':cmd,'tracked_source_files_verified_before_and_after':len(manifest['files']),'parent':manifest['parent']}
if (evd/'vitest-results.json').exists():
 d=json.loads((evd/'vitest-results.json').read_text());receipt['counts']={k:d.get(k) for k in ['numPassedTests','numFailedTests','numPendingTests','numTodoTests','numTotalTests','numPassedTestSuites','numFailedTestSuites','numTotalTestSuites','success']}
 receipt['files']=len(d['testResults'])
(evd/'test-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True)
raise SystemExit(p.returncode)
