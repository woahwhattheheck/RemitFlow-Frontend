import config from '/dev/shm/relay17-rf297-acceptance/vite.config.js';
export default { ...config, cacheDir: '/dev/shm/relay17-rf297-acceptance-evidence/vite-cache' };
