import base from './vite.config.js';
export default { ...base, cacheDir: '/dev/shm/relay17-rf298-cache' };
