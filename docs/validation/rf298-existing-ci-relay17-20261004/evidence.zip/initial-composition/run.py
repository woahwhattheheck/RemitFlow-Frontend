from pathlib import Path
import datetime, hashlib, json, os, subprocess, time
root=Path('/dev/shm/relay17-rf298-acceptance')
ev=Path('/dev/shm/relay17-rf298-evidence')
tmp=Path('/dev/shm/relay17-rf298-tmp'); tmp.mkdir(exist_ok=True)
cache=Path('/dev/shm/relay17-rf298-cache'); cache.mkdir(exist_ok=True)
manifest=json.loads((ev/'candidate-manifest.json').read_text())
def blob(path):
    b=path.read_bytes()
    return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def verify():
    errors=[f['path'] for f in manifest['files'] if blob(root/f['path'])!=f['sha']]
    if errors: raise RuntimeError('Tracked source changed: '+repr(errors))
verify()
config="import base from './vite.config.js';\nexport default { ...base, cacheDir: '/dev/shm/relay17-rf298-cache' };\n"
(root/'relay17.vitest.config.mjs').write_text(config)
(ev/'relay17.vitest.config.mjs').write_text(config)
env=os.environ.copy()
env.update(TMPDIR=str(tmp),npm_config_cache='/dev/shm/relay17-rf298-npm-cache',npm_config_logs_dir='/dev/shm/relay17-rf298-npm-logs')
commands=[
 ('tests',['node','node_modules/vitest/vitest.mjs','run','test/integration','test/unit','test/components','test/services','test/lighthouse-config.test.js','test/security','--config','relay17.vitest.config.mjs','--maxWorkers=2','--reporter=default','--reporter=json','--outputFile.json='+str(ev/'vitest-results.json')]),
 ('audit',['npm','audit','--audit-level=critical','--json','--fetch-retries=0','--fetch-timeout=20000']),
 ('build',['npm','run','build'])
]
receipt=dict(repository=manifest['repository'],parent=manifest['parent'],tested_tree=manifest['tree'],source_files=len(manifest['files']),node=subprocess.run(['node','--version'],capture_output=True,text=True).stdout.strip(),commands=[])
for name,args in commands:
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick=time.monotonic()
    out=ev/({'tests':'vitest-output.log','audit':'audit-results.json','build':'build-output.log'}[name])
    with out.open('w') as f, (ev/(name+'-stderr.log')).open('w') as err:
        p=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=err,text=True)
    row=dict(gate=name,command=args,started_at=start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,exit_code=p.returncode)
    receipt['commands'].append(row)
    verify()
    (ev/'run-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if name=='tests' and (ev/'vitest-results.json').exists():
        data=json.loads((ev/'vitest-results.json').read_text())
        print(json.dumps({k:data.get(k) for k in ('success','numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests','numTotalTestSuites','numPassedTestSuites','numFailedTestSuites')}),flush=True)
        failures=[{'file':x['name'],'status':x['status'],'failed':[(y.get('fullName'),y.get('failureMessages')) for y in x.get('assertionResults',[]) if y.get('status')=='failed']} for x in data.get('testResults',[]) if x.get('status')!='passed']
        print(json.dumps({'file_count':len(data.get('testResults',[])),'failures':failures}),flush=True)
    if name=='audit':
        try:
            data=json.loads(out.read_text());print(json.dumps({'audit':data.get('metadata',{}).get('vulnerabilities')}),flush=True)
        except Exception as e: print('Audit JSON parse:',str(e),flush=True)
    if name=='build':print(out.read_text()[-2200:],flush=True)
receipt['source_unchanged_after']=True
(ev/'run-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
