import base from './vite.config.js';

// Keep repository behavior; isolate only the writable Vite cache.
export default {
  ...base,
  cacheDir: '/dev/shm/relay17-rf296-combined/validation/relay17-combined/vite-cache',
};
