from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path('/dev/shm/relay17-rf296-combined')
out = root / 'validation/relay17-combined'
source = json.loads((out / 'pinned-source.json').read_text())


def verify_source():
    differences = []
    for item in source['files']:
        path = root / item['path']
        if not path.is_file():
            differences.append({'path': item['path'], 'actual': 'missing'})
            continue
        data = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if actual != item['sha']:
            differences.append({'path': item['path'], 'expected': item['sha'], 'actual': actual})
    if differences:
        raise RuntimeError(json.dumps(differences))
    return len(source['files'])


verified_before = verify_source()
tmp = out / 'tmp'
tmp.mkdir(exist_ok=True)
environment = os.environ.copy()
environment['TMPDIR'] = str(tmp)
command = [
    shutil.which('node'), 'node_modules/vitest/vitest.mjs', 'run',
    'test/integration', 'test/unit', 'test/components', 'test/services',
    'test/lighthouse-config.test.js', 'test/security',
    '--config', 'relay17.vitest.config.mjs', '--maxWorkers=2',
    '--reporter=default', '--reporter=json',
    '--outputFile.json=' + str(out / 'vitest-results.json'),
]
started_at = datetime.now(timezone.utc).isoformat()
start = time.monotonic()
with (out / 'vitest-output.log').open('w') as log:
    result = subprocess.run(command, cwd=root, env=environment,
                            stdout=log, stderr=subprocess.STDOUT, timeout=300)
duration = time.monotonic() - start
verified_after = verify_source()
data = json.loads((out / 'vitest-results.json').read_text())
receipt = {
    'source_commit': source['commit'],
    'source_tree': source['tree'],
    'verified_source_file_count_before': verified_before,
    'verified_source_file_count_after': verified_after,
    'started_at_utc': started_at,
    'finished_at_utc': datetime.now(timezone.utc).isoformat(),
    'elapsed_seconds': duration,
    'node_version': subprocess.check_output([shutil.which('node'), '--version'], text=True).strip(),
    'vitest_version': '4.1.10',
    'command': command,
    'temporary_directory': str(tmp),
    'config_change': 'Imports the repository Vite config; overrides only cacheDir.',
    'exit_code': result.returncode,
    'success': data['success'],
    'tests_total': data['numTotalTests'],
    'tests_passed': data['numPassedTests'],
    'tests_failed': data['numFailedTests'],
    'tests_pending': data['numPendingTests'],
    'tests_todo': data.get('numTodoTests', 0),
    'files_total': len(data['testResults']),
    'files_passed': sum(item['status'] == 'passed' for item in data['testResults']),
    'files_failed': sum(item['status'] == 'failed' for item in data['testResults']),
    'failed_cases': [
        {'file': item['name'], 'name': case['fullName'], 'failure_messages': case['failureMessages']}
        for item in data['testResults'] for case in item['assertionResults']
        if case['status'] == 'failed'
    ],
    'snapshot': data.get('snapshot'),
}
for name in ['pinned-source.json', 'vitest-output.log', 'vitest-results.json']:
    receipt[name + '_sha256'] = hashlib.sha256((out / name).read_bytes()).hexdigest()
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)
